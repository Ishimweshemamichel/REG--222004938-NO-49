/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package studentregistration;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 *
 * @author user
 */
public class DBConnection {
    // Establishing database connection details
    static final String DB_URL = "jdbc:mysql://localhost/registrationform";
    static final String  USER = "root";
    static final String PASS = "";
    
    // Method to establish a database connection
    public static Connection DBConnection () {
         Connection con = null;
        try {
            // Attempting to connect to the database
            con = DriverManager.getConnection(DB_URL,USER,PASS);
            return con;
        } catch (SQLException ex) {
            // Handling connection errors
            System.out.println("please error in connection");
            return null;
        }
        
    }
    
}
