-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Dec 11, 2023 at 09:38 PM
-- Server version: 10.4.28-MariaDB
-- PHP Version: 8.2.4

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `student`
--

-- --------------------------------------------------------

--
-- Table structure for table `student`
--

CREATE TABLE `student` (
  `firstname` varchar(20) NOT NULL,
  `lastname` varchar(20) NOT NULL,
  `regno` int(9) NOT NULL,
  `Pin` int(10) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `student`
--

INSERT INTO `student` (`firstname`, `lastname`, `regno`, `Pin`) VALUES
('hhbh', 'abzjkkab', 2435, 0),
('RWIGARA', 'Rodrigue', 222003167, 0),
('Rwigara ', 'Rodrigue', 222003167, 0),
('ishimwe ', 'michel', 22009988, 0),
('rr', 'hh', 4454222, 0),
('jh', 'mm', 67, 0),
('jazzy', 'beat', 2091, 0),
('Rwigara', 'Rodrigue', 222003167, 0),
('vcghf', 'mjbhkj', 4454678, 0),
('vcghf', 'mjbhkj', 4454678, 0),
('vcghf', 'mjbhkj', 4454678, 0),
('vcghf', 'mjbhkj', 4454678, 0),
('vcghf', 'mjbhkj', 4454678, 0),
('manzi', 'celse', 22222, 0);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
